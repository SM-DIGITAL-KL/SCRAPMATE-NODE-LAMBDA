const express = require('express');
const router = express.Router();
const { apiKeyCheck } = require('../../middleware/apiKeyMiddleware');
const { profileUpload: profileUploadMulter } = require('../../utils/fileUpload');
const UserController = require('../../controllers/userController');

const profileUpload = profileUploadMulter.single('profile_photo');

router.use(apiKeyCheck);

// ==================== USER ROUTES ====================
router.get('/users_profile_view/:id', UserController.usersProfileView);
router.get('/get_user_by_name/:name', UserController.getUserByName);
router.post('/user_profile_pic_edit', profileUpload, UserController.userProfilePicEdit);
router.post('/userProEdit', UserController.userProEdit);
router.get('/cust_dash_counts/:id', UserController.custDashCounts);
router.post('/cust_ads_type_edit', UserController.custAdsTypeEdit);
router.post('/fcm_token_store', UserController.fcmTokenStore);
router.get('/fcmTokenClear/:userid', UserController.fcmTokenClear);

module.exports = router;

