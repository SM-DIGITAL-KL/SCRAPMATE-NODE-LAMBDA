const express = require('express');
const router = express.Router();
const { apiKeyCheck } = require('../../middleware/apiKeyMiddleware');
const { shopImageUpload: shopImageUploadMulter } = require('../../utils/fileUpload');
const ShopController = require('../../controllers/shopController');
const ProductController = require('../../controllers/productController');

const shopImageUpload = shopImageUploadMulter.single('shop_img');

router.use(apiKeyCheck);

// ==================== SHOP ROUTES ====================
router.post('/shop_image_upload', shopImageUpload, ShopController.shopImageUpload);
router.get('/shop_image_delete/:id', ShopController.shopImageDelete);
router.get('/shop_image_list/:id', ShopController.shopImageList);
router.get('/shop_cat_list/:id', ShopController.shopCatList);
router.get('/shop_item_list/:shop_id/:cat_id', ProductController.shopItemList);
router.get('/shop_orders/:shop_id', ShopController.shopOrders);
router.get('/shop_orders/:shop_id/:status', ShopController.shopOrders);
router.get('/shop_orders/:shop_id/:status/:offset', ShopController.shopOrders);
router.get('/shop_dash_counts/:id', ShopController.shopDashCounts);
router.get('/shopReviews/:shop_id', ShopController.shopReviews);
router.post('/shops_list_for_sale', ShopController.shopsListForSale);
router.post('/shop_ads_type_edit', ShopController.shopAdsTypeEdit);

module.exports = router;

