/**
 * Auth Service Lambda Handler
 * Handles authentication, login, and user registration
 */

const serverless = require('serverless-http');
const express = require('express');
const app = express();

// Load environment variables
require('dotenv').config();
const { loadEnvFromFile } = require('../../utils/loadEnv');
loadEnvFromFile();

// Initialize DynamoDB
require('../../config/dynamodb');

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS middleware
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, api-key');
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  next();
});

// Import routes
const authRoutes = require('./routes');

// Mount routes
app.use('/api', authRoutes);

// Error handler
app.use((err, req, res, next) => {
  console.error('Auth Service Error:', err);
  res.status(err.status || 500).json({
    status: 'error',
    msg: err.message || 'Internal server error',
    data: ''
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    status: 'error',
    msg: 'Auth endpoint not found',
    data: ''
  });
});

// Wrap with serverless-http
const handler = serverless(app, {
  binary: ['application/octet-stream', 'image/*', 'multipart/form-data']
});

exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return handler(event, context);
};

