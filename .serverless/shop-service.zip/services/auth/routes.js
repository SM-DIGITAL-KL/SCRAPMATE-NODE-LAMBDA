/**
 * Auth Service Routes
 * Authentication, login, and user registration endpoints
 */

const express = require('express');
const router = express.Router();
const { apiKeyCheck } = require('../../middleware/apiKeyMiddleware');
const { profileUpload: profileUploadMulter } = require('../../utils/fileUpload');

// Controllers
const AuthController = require('../../controllers/authController');
const WebLoginController = require('../../controllers/webLoginController');

const profileUpload = profileUploadMulter.single('profile_photo');

// Public route (no API key required)
router.get('/', AuthController.index);

// All routes below require API key
router.use(apiKeyCheck);

// ==================== AUTHENTICATION ROUTES ====================
router.get('/login_app/:mob', AuthController.loginApp);
router.post('/login', AuthController.login);
router.post('/dologin', WebLoginController.doLogin);
router.post('/users_register', profileUpload, AuthController.usersRegister);
router.post('/user_mob_verification', AuthController.userMobVerification);

module.exports = router;

