const { getDynamoDBClient } = require('../config/dynamodb');
const { GetCommand, PutCommand, UpdateCommand, ScanCommand, BatchGetCommand, BatchWriteCommand } = require('@aws-sdk/lib-dynamodb');
const redis = require('../config/redis');
const bcrypt = require('bcryptjs');

const TABLE_NAME = 'users';

class User {
  // Create a new user
  static async create(name, email, mobNum, userType, password = null) {
      try {
      const client = getDynamoDBClient();
        const hashedPassword = password ? await bcrypt.hash(password, 10) : await bcrypt.hash(mobNum, 10);
      
      // Generate ID (you might want to use a sequence or UUID)
      // For now, we'll use timestamp + random
      const id = Date.now() + Math.floor(Math.random() * 1000);
      
      const user = {
        id: id,
        name: name,
        email: email,
        mob_num: typeof mobNum === 'string' && !isNaN(mobNum) ? parseInt(mobNum) : mobNum,
        user_type: userType,
        password: hashedPassword,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const command = new PutCommand({
        TableName: TABLE_NAME,
        Item: user
      });

      await client.send(command);
          
          // Cache user in Redis
          try {
        await redis.set(`user:${id}`, JSON.stringify(user));
          } catch (redisErr) {
            console.error('Redis cache error:', redisErr);
          }

      // Remove password from returned user
      const { password: _, ...userWithoutPassword } = user;
      return userWithoutPassword;
      } catch (err) {
      throw err;
      }
  }

  // Find user by mobile number
  static async findByMobile(mobNum) {
    try {
      const client = getDynamoDBClient();
      const mobileValue = typeof mobNum === 'string' && !isNaN(mobNum) ? parseInt(mobNum) : mobNum;
      
      const command = new ScanCommand({
        TableName: TABLE_NAME,
        FilterExpression: 'mob_num = :mobile',
        ExpressionAttributeValues: {
          ':mobile': mobileValue
        },
        Limit: 1
      });

      const response = await client.send(command);
      if (response.Items && response.Items.length > 0) {
        const user = response.Items[0];
        const { password: _, ...userWithoutPassword } = user;
        return userWithoutPassword;
      }
      return null;
    } catch (err) {
      throw err;
    }
  }

  // Find user by email
  static async findByEmail(email) {
    try {
      const client = getDynamoDBClient();
      
      // Scan with pagination to find the matching email
      // Note: Limit in ScanCommand limits items scanned, not filtered results
      let lastKey = null;
      
      do {
        const params = {
          TableName: TABLE_NAME,
          FilterExpression: 'email = :email',
          ExpressionAttributeValues: {
            ':email': email
          }
        };
        
        if (lastKey) {
          params.ExclusiveStartKey = lastKey;
        }
        
        const command = new ScanCommand(params);
        const response = await client.send(command);
        
        if (response.Items && response.Items.length > 0) {
          // Found the user
          const user = response.Items[0];
          const { password: _, ...userWithoutPassword } = user;
          return userWithoutPassword;
        }
        
        lastKey = response.LastEvaluatedKey;
      } while (lastKey);
      
      return null;
    } catch (err) {
      throw err;
    }
  }

  // Check if email exists
  static async emailExists(email) {
    try {
      const user = await this.findByEmail(email);
      return !!user;
    } catch (err) {
      throw err;
    }
  }

  // Check if mobile exists
  static async mobileExists(mobNum) {
    try {
      const user = await this.findByMobile(mobNum);
      return !!user;
    } catch (err) {
      throw err;
    }
  }

  // Update FCM token
  static async updateFcmToken(userId, fcmToken) {
    try {
      const client = getDynamoDBClient();
      const id = typeof userId === 'string' && !isNaN(userId) ? parseInt(userId) : userId;
      
      const command = new UpdateCommand({
        TableName: TABLE_NAME,
        Key: { id: id },
        UpdateExpression: 'SET fcm_token = :token, updated_at = :updated',
        ExpressionAttributeValues: {
          ':token': fcmToken,
          ':updated': new Date().toISOString()
        }
      });

      await client.send(command);
      return { affectedRows: 1 };
    } catch (err) {
      throw err;
    }
  }

  // Clear FCM token
  static async clearFcmToken(userId) {
    try {
      const client = getDynamoDBClient();
      const id = typeof userId === 'string' && !isNaN(userId) ? parseInt(userId) : userId;
      
      const command = new UpdateCommand({
        TableName: TABLE_NAME,
        Key: { id: id },
        UpdateExpression: 'REMOVE fcm_token SET updated_at = :updated',
        ExpressionAttributeValues: {
          ':updated': new Date().toISOString()
        }
      });

      await client.send(command);
      return { affectedRows: 1 };
    } catch (err) {
      throw err;
    }
  }

  // Update user profile
  static async updateProfile(userId, data) {
    try {
      const client = getDynamoDBClient();
      const id = typeof userId === 'string' && !isNaN(userId) ? parseInt(userId) : userId;
      
      // Build update expression
      const updateExpressions = [];
      const expressionAttributeValues = {};
      const expressionAttributeNames = {};
      
      Object.keys(data).forEach((key, index) => {
        if (data[key] !== undefined) {
          const attrName = `#attr${index}`;
          const attrValue = `:val${index}`;
          updateExpressions.push(`${attrName} = ${attrValue}`);
          expressionAttributeNames[attrName] = key;
          expressionAttributeValues[attrValue] = data[key];
        }
      });
      
      if (updateExpressions.length === 0) {
        return { affectedRows: 0 };
      }
      
      updateExpressions.push('#updated = :updated');
      expressionAttributeNames['#updated'] = 'updated_at';
      expressionAttributeValues[':updated'] = new Date().toISOString();
      
      const command = new UpdateCommand({
        TableName: TABLE_NAME,
        Key: { id: id },
        UpdateExpression: `SET ${updateExpressions.join(', ')}`,
        ExpressionAttributeNames: expressionAttributeNames,
        ExpressionAttributeValues: expressionAttributeValues
      });

      await client.send(command);
      return { affectedRows: 1 };
    } catch (err) {
      throw err;
    }
  }

  // Get user by ID (checks Redis first, then DynamoDB)
  static async findById(id) {
    // Check Redis first
    try {
      const cachedUser = await redis.get(`user:${id}`);
      if (cachedUser) {
        console.log(`⚡ Redis cache hit user:${id}`);
        const parsedUser = typeof cachedUser === 'string' ? JSON.parse(cachedUser) : cachedUser;
        const { password: _, ...userWithoutPassword } = parsedUser;
        return userWithoutPassword;
      }
    } catch (redisErr) {
      console.error('Redis get error:', redisErr);
    }

    // If not found in Redis, check DynamoDB
    try {
      const client = getDynamoDBClient();
      const userId = typeof id === 'string' && !isNaN(id) ? parseInt(id) : id;
      
      const command = new GetCommand({
        TableName: TABLE_NAME,
        Key: { id: userId }
      });

      const response = await client.send(command);
      
      if (!response.Item) {
        return null;
      }

      const user = response.Item;

        // Store in Redis cache
        try {
        await redis.set(`user:${userId}`, user);
        } catch (redisErr) {
          console.error('Redis cache error:', redisErr);
      }

      const { password: _, ...userWithoutPassword } = user;
      return userWithoutPassword;
    } catch (err) {
      throw err;
    }
  }

  // Find users by IDs (batch operation)
  static async findByIds(ids) {
    try {
      const client = getDynamoDBClient();
      const allUsers = [];
      
      // DynamoDB BatchGetItem can handle up to 100 items per request
      const batchSize = 100;
      
      for (let i = 0; i < ids.length; i += batchSize) {
        const batch = ids.slice(i, i + batchSize);
        const keys = batch.map(id => ({
          id: typeof id === 'string' && !isNaN(id) ? parseInt(id) : id
        }));

        const command = new BatchGetCommand({
          RequestItems: {
            [TABLE_NAME]: {
              Keys: keys
            }
          }
        });

        const response = await client.send(command);
        if (response.Responses && response.Responses[TABLE_NAME]) {
          const users = response.Responses[TABLE_NAME].map(user => {
            const { password: _, ...userWithoutPassword } = user;
            return userWithoutPassword;
          });
          allUsers.push(...users);
        }
      }

      return allUsers;
    } catch (err) {
      throw err;
    }
  }

  // Find user by name (exact match)
  static async findByName(name) {
    try {
      const client = getDynamoDBClient();
      
      const command = new ScanCommand({
        TableName: TABLE_NAME,
        FilterExpression: 'name = :name',
        ExpressionAttributeValues: {
          ':name': name
        },
        Limit: 1
      });

      const response = await client.send(command);
      if (response.Items && response.Items.length > 0) {
        const user = response.Items[0];
        const { password: _, ...userWithoutPassword } = user;
        return userWithoutPassword;
      }
      return null;
    } catch (err) {
      throw err;
    }
  }

  // Search users by name (partial match)
  static async searchByName(name, limit = 10) {
    try {
      const client = getDynamoDBClient();
      
      // DynamoDB doesn't support LIKE, so we scan and filter in memory
      // For production, consider using a GSI or full-text search service
      const command = new ScanCommand({
        TableName: TABLE_NAME,
        Limit: 1000 // Scan more items to find matches
      });

      const response = await client.send(command);
      const allUsers = response.Items || [];
      
      // Filter by name containing the search term (case-insensitive)
      const searchTerm = name.toLowerCase();
      const matchingUsers = allUsers
        .filter(user => user.name && user.name.toLowerCase().includes(searchTerm))
        .slice(0, limit)
        .map(user => {
          const { password: _, ...userWithoutPassword } = user;
          return userWithoutPassword;
        });
      
      return matchingUsers;
    } catch (err) {
      throw err;
    }
  }

  // Batch create users
  static async batchCreate(users) {
    try {
      const client = getDynamoDBClient();
      const allResults = [];
      
      // DynamoDB BatchWriteItem can handle up to 25 items per request
      const batchSize = 25;
      
      for (let i = 0; i < users.length; i += batchSize) {
        const batch = users.slice(i, i + batchSize);
        const putRequests = batch.map(user => ({
          PutRequest: {
            Item: {
              ...user,
              id: user.id || (Date.now() + Math.floor(Math.random() * 1000)),
              created_at: user.created_at || new Date().toISOString(),
              updated_at: user.updated_at || new Date().toISOString()
            }
          }
        }));

        const command = new BatchWriteCommand({
          RequestItems: {
            [TABLE_NAME]: putRequests
          }
        });

        const response = await client.send(command);
        allResults.push(response);
      }

      return allResults;
    } catch (err) {
      throw err;
    }
  }

  // Batch update users
  static async batchUpdate(updates) {
    // DynamoDB doesn't have batch update, so we'll do individual updates
    // But we can parallelize them
    try {
      const promises = updates.map(update => {
        const { id, ...data } = update;
        return this.updateProfile(id, data);
      });
      
      await Promise.all(promises);
      return { affectedRows: updates.length };
    } catch (err) {
      throw err;
    }
  }

  // Count users by user_type
  static async countByUserType(userType) {
    try {
      const client = getDynamoDBClient();
      let lastKey = null;
      let count = 0;
      
      do {
        const params = {
          TableName: TABLE_NAME,
          FilterExpression: 'user_type = :userType',
          ExpressionAttributeValues: {
            ':userType': userType
          }
        };
        
        if (lastKey) {
          params.ExclusiveStartKey = lastKey;
        }
        
        const command = new ScanCommand(params);
        const response = await client.send(command);
        
        if (response.Items) {
          count += response.Items.length;
        }
        
        lastKey = response.LastEvaluatedKey;
      } while (lastKey);
      
      return count;
    } catch (err) {
      throw err;
    }
  }

  // Count users by user_type and current month
  static async countByUserTypeAndCurrentMonth(userType) {
    try {
      const client = getDynamoDBClient();
      const now = new Date();
      const currentMonth = now.getMonth() + 1;
      const currentYear = now.getFullYear();
      
      let lastKey = null;
      let count = 0;
      
      do {
        const params = {
          TableName: TABLE_NAME,
          FilterExpression: 'user_type = :userType',
          ExpressionAttributeValues: {
            ':userType': userType
          }
        };
        
        if (lastKey) {
          params.ExclusiveStartKey = lastKey;
        }
        
        const command = new ScanCommand(params);
        const response = await client.send(command);
        
        if (response.Items) {
          // Filter by current month in memory
          const matching = response.Items.filter(user => {
            if (!user.created_at) return false;
            const userDate = new Date(user.created_at);
            return userDate.getMonth() + 1 === currentMonth && userDate.getFullYear() === currentYear;
          });
          count += matching.length;
        }
        
        lastKey = response.LastEvaluatedKey;
      } while (lastKey);
      
      return count;
    } catch (err) {
      throw err;
    }
  }

  // Get users with FCM token by user_type
  static async findWithFcmTokenByUserType(userType) {
    try {
      const client = getDynamoDBClient();
      let lastKey = null;
      const users = [];
      
      do {
        const params = {
          TableName: TABLE_NAME,
          FilterExpression: 'user_type = :userType AND attribute_exists(fcm_token)',
          ExpressionAttributeValues: {
            ':userType': userType
          }
        };
        
        if (lastKey) {
          params.ExclusiveStartKey = lastKey;
        }
        
        const command = new ScanCommand(params);
        const response = await client.send(command);
        
        if (response.Items) {
          // Filter out users without fcm_token (attribute_exists might not work as expected)
          const withToken = response.Items.filter(u => u.fcm_token);
          users.push(...withToken.map(u => ({
            id: u.id,
            name: u.name
          })));
        }
        
        lastKey = response.LastEvaluatedKey;
      } while (lastKey);
      
      return users;
    } catch (err) {
      throw err;
    }
  }

  // Get monthly count by user_type
  static async getMonthlyCountByUserType(userType) {
    try {
      const client = getDynamoDBClient();
      const currentYear = new Date().getFullYear();
      const monthlyCounts = new Array(12).fill(0);
      
      let lastKey = null;
      const allUsers = [];
      
      do {
        const params = {
          TableName: TABLE_NAME,
          FilterExpression: 'user_type = :userType',
          ExpressionAttributeValues: {
            ':userType': userType
          }
        };
        
        if (lastKey) {
          params.ExclusiveStartKey = lastKey;
        }
        
        const command = new ScanCommand(params);
        const response = await client.send(command);
        
        if (response.Items) {
          allUsers.push(...response.Items);
        }
        
        lastKey = response.LastEvaluatedKey;
      } while (lastKey);
      
      // Count by month
      allUsers.forEach(user => {
        if (user.created_at) {
          const date = new Date(user.created_at);
          if (date.getFullYear() === currentYear) {
            const month = date.getMonth(); // 0-11
            monthlyCounts[month]++;
          }
        }
      });
      
      return monthlyCounts;
    } catch (err) {
      throw err;
    }
  }

  // Get all users
  static async getAll() {
    try {
      const client = getDynamoDBClient();
      let lastKey = null;
      const allUsers = [];
      
      do {
        const params = {
          TableName: TABLE_NAME
        };
        
        if (lastKey) {
          params.ExclusiveStartKey = lastKey;
        }
        
        const command = new ScanCommand(params);
        const response = await client.send(command);
        
        if (response.Items) {
          allUsers.push(...response.Items);
        }
        
        lastKey = response.LastEvaluatedKey;
      } while (lastKey);
      
      return allUsers;
    } catch (err) {
      throw err;
    }
  }

  // Count all users
  static async count() {
    try {
      const customers = await this.countByUserType('C');
      const shops = await this.countByUserType('S');
      const deliveryBoys = await this.countByUserType('D');
      return customers + shops + deliveryBoys;
    } catch (err) {
      throw err;
    }
  }
}

module.exports = User;
