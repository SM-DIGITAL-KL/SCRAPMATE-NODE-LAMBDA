const User = require('../models/User');
const Shop = require('../models/Shop');
const Order = require('../models/Order');
const DeliveryBoy = require('../models/DeliveryBoy');
const CallLog = require('../models/CallLog');
const ProductCategory = require('../models/ProductCategory');
const RedisCache = require('../utils/redisCache');

class AdminPanelController {
  // Dashboard data
  static async dashboard(req, res) {
    console.log('✅ AdminPanelController.dashboard called - API request received');
    console.log('Request headers:', req.headers);
    
    // Check Redis cache first
    const cacheKey = RedisCache.adminKey('dashboard');
    try {
      const cached = await RedisCache.get(cacheKey);
      if (cached) {
        console.log('⚡ Dashboard cache hit');
        return res.json({
          status: 'success',
          msg: 'Dashboard data retrieved',
          data: cached
        });
      }
    } catch (err) {
      console.error('Redis get error:', err);
    }
    
    try {
      // Get all counts using DynamoDB models
      const [
        shops,
        customers,
        this_month_customers,
        this_month_vendors,
        deliveryboys,
        users,
        orders,
        calllogs,
        todayscalllogs,
        recent_orders
      ] = await Promise.all([
        Shop.countByDelStatus(1),
        User.countByUserType('C'),
        User.countByUserTypeAndCurrentMonth('C'),
        User.countByUserTypeAndCurrentMonth('S'),
        DeliveryBoy.count(),
        (async () => {
          const UserAdmin = require('../models/UserAdmin');
          return await UserAdmin.count();
        })(),
        Order.count(),
        CallLog.count(),
        CallLog.countByDate(),
        Order.getRecent(8)
      ]);

      const result = {
        shops,
        customers,
        this_month_customers,
        this_month_vendors,
        deliveryboys,
        users,
        orders,
        calllogs,
        todayscalllogs,
        recent_orders
      };

      // Get monthly statistics using model methods
      result.month_wise_customers_count = await User.getMonthlyCountByUserType('C');
      result.month_wise_vendor_count = await User.getMonthlyCountByUserType('S');
      result.month_wise_orders_count = await Order.getMonthlyCount();
      result.month_wise_completed_orders_count = await Order.getMonthlyCount(4);
      result.month_wise_pending_orders_count = await Order.getMonthlyPendingCount();
      result.locations = [];

      // Cache dashboard data for 5 minutes (300 seconds)
      try {
        await RedisCache.set(cacheKey, result, '30days');
        console.log('💾 Dashboard data cached');
      } catch (err) {
        console.error('Redis cache set error:', err);
      }

      res.json({
        status: 'success',
        msg: 'Dashboard data retrieved',
        data: result
      });
    } catch (error) {
      console.error('Dashboard API error:', error);
      res.status(500).json({
        status: 'error',
        msg: 'Error loading dashboard data',
        data: null
      });
    }
  }

  // These methods are now handled by model methods:
  // - getMonthlyCount() -> User.getMonthlyCountByUserType() or Order.getMonthlyCount()
  // - getMonthlyPendingOrders() -> Order.getMonthlyPendingCount()

  // Users
  static async users(req, res) {
    res.json({
      status: 'success',
      msg: 'Users page data',
      data: { pagename: 'Users' }
    });
  }

  static async getUserById(req, res) {
    try {
      const { id } = req.params;
      
      // Check Redis cache first
      const cacheKey = RedisCache.adminKey('user', id);
      try {
        const cached = await RedisCache.get(cacheKey);
        if (cached) {
          console.log('⚡ User cache hit:', cacheKey);
          return res.json({
            status: 'success',
            msg: 'User retrieved',
            data: cached
          });
        }
      } catch (err) {
        console.error('Redis get error:', err);
      }
      
      // Use UserAdmin model to fetch user admin by ID
      const UserAdmin = require('../models/UserAdmin');
      const userData = await UserAdmin.findById(id);
      
      // Cache user data for 1 hour
      if (userData) {
        try {
          await RedisCache.set(cacheKey, userData, '30days');
          console.log('💾 User data cached:', cacheKey);
        } catch (err) {
          console.error('Redis cache set error:', err);
        }
      }
      
      res.json({
        status: 'success',
        msg: 'User retrieved',
        data: userData
      });
    } catch (error) {
      res.status(500).json({
        status: 'error',
        msg: 'Error fetching user',
        data: null
      });
    }
  }

  static async viewUsers(req, res) {
    try {
      console.log('✅ AdminPanelController.viewUsers called - fetching user_admins');
      
      // Check Redis cache first
      const cacheKey = RedisCache.adminKey('view_users');
      try {
        const cached = await RedisCache.get(cacheKey);
        if (cached) {
          console.log('⚡ View users cache hit');
          return res.json({ 
            status: 'success',
            msg: 'Users retrieved',
            data: cached 
          });
        }
      } catch (err) {
        console.error('Redis get error:', err);
      }
      
      // Use UserAdmin model to fetch all user admins
      const UserAdmin = require('../models/UserAdmin');
      const results = await UserAdmin.getAll();
      console.log(`✅ Found ${results.length} user_admins`);
      
      // Cache users list for 10 minutes
      try {
        await RedisCache.set(cacheKey, results, '30days');
        console.log('💾 Users list cached');
      } catch (err) {
        console.error('Redis cache set error:', err);
      }
      
      res.json({ 
        status: 'success',
        msg: 'Users retrieved',
        data: results 
      });
    } catch (error) {
      console.error('viewUsers error:', error);
      res.json({ 
        status: 'error',
        msg: 'Error fetching users',
        data: [] 
      });
    }
  }

  // Call log search
  static async callLogSearch(req, res) {
    res.json({
      status: 'success',
      msg: 'Call log search page',
      data: { pagename: 'Call Log Search' }
    });
  }

  static async getcallLogSearch(req, res) {
    const draw = parseInt(req.query.draw) || 1;
    const start = parseInt(req.query.start) || 0;
    const length = parseInt(req.query.length) || 10;
    const search = req.query.search?.value || '';

    // Check Redis cache first
    const cacheKey = RedisCache.adminKey('callLogSearch', null, { draw, start, length, search });
    try {
      const cached = await RedisCache.get(cacheKey);
      if (cached) {
        console.log('⚡ Call log search cache hit');
        return res.json(cached);
      }
    } catch (err) {
      console.error('Redis get error:', err);
    }

    try {
      // Use CallLog model's searchWithNames method
      const { data: results, total } = await CallLog.searchWithNames(search, length, start);

      const formattedData = results.map((row, index) => ({
        DT_RowIndex: start + index + 1,
        user_name: row.user_name || '',
        shop_name: row.shop_name || '',
        created_at: new Date(row.created_at).toLocaleString()
      }));

      const response = {
        draw,
        recordsTotal: total,
        recordsFiltered: total,
        data: formattedData
      };
      
      // Cache call log search for 2 minutes
      try {
        await RedisCache.set(cacheKey, response, '30days');
        console.log('💾 Call log search cached');
      } catch (err) {
        console.error('Redis cache set error:', err);
      }

      res.json(response);
    } catch (error) {
      console.error('Call log search error:', error);
      res.json({ draw, recordsTotal: 0, recordsFiltered: 0, data: [] });
    }
  }

  // Sign up report
  static async signUpReport(req, res) {
    // Log immediately when function is called
    console.log('\n\n');
    console.log('═══════════════════════════════════════════════════════════');
    console.log('🟢🟢🟢 signUpReport FUNCTION CALLED 🟢🟢🟢');
    console.log('═══════════════════════════════════════════════════════════');
    console.log('Timestamp:', new Date().toISOString());
    
    try {
      const { start_date, end_date, user_type } = req.query;
      
      // Check Redis cache first (only if all params provided)
      if (start_date && end_date && user_type) {
        const cacheKey = RedisCache.adminKey('signUpReport', null, { start_date, end_date, user_type });
        try {
          const cached = await RedisCache.get(cacheKey);
          if (cached) {
            console.log('⚡ Sign up report cache hit');
            return res.json(cached);
          }
        } catch (err) {
          console.error('Redis get error:', err);
        }
      }
      
      console.log('═══════════════════════════════════════════════════════════');
      console.log('🟢 AdminPanelController.signUpReport called');
      console.log('═══════════════════════════════════════════════════════════');
      console.log('   Request Method:', req.method);
      console.log('   Request Path:', req.path);
      console.log('   Query params:', { start_date, end_date, user_type });
      
      if (!start_date || !end_date || !user_type) {
        console.log('⚠️ signUpReport: Missing required params, returning page data');
        console.log('   Missing:', {
          start_date: !start_date ? 'MISSING' : 'OK',
          end_date: !end_date ? 'MISSING' : 'OK',
          user_type: !user_type ? 'MISSING' : 'OK'
        });
        return res.json({
          status: 'success',
          msg: 'Sign up report page',
          data: { pagename: 'Sign Up Report' }
        });
      }

      // Map user_type to readable name
      const userTypeMap = {
        'S': 'Vendors',
        'C': 'Customers',
        'D': 'Door Step Buyers'
      };
      const userTypeName = userTypeMap[user_type] || `Unknown (${user_type})`;
      
      console.log('📊 Report Parameters:');
      console.log('   User Type:', user_type, `(${userTypeName})`);
      console.log('   Start Date:', start_date);
      console.log('   End Date:', end_date);
      console.log('   Date Range:', `${start_date} to ${end_date}`);

      // Build query based on user_type to join with appropriate table
      let query;
      let params;
      let tableJoin = '';
      
      if (user_type === 'S') {
        // Vendors - join with shops table
        tableJoin = 'shops';
        query = `
          SELECT 
            u.id,
            u.name,
            u.email,
            u.mob_num,
            s.address,
            s.place,
            u.created_at
          FROM users u
          LEFT JOIN shops s ON u.id = s.user_id
          WHERE u.created_at BETWEEN ? AND ? AND u.user_type = ?
          ORDER BY u.created_at DESC
        `;
        params = [`${start_date} 00:00:00`, `${end_date} 23:59:59`, user_type];
      } else if (user_type === 'C') {
        // Customers - join with customer table
        tableJoin = 'customer';
        query = `
          SELECT 
            u.id,
            u.name,
            u.email,
            u.mob_num,
            c.address,
            c.place,
            u.created_at
          FROM users u
          LEFT JOIN customer c ON u.id = c.user_id
          WHERE u.created_at BETWEEN ? AND ? AND u.user_type = ?
          ORDER BY u.created_at DESC
        `;
        params = [`${start_date} 00:00:00`, `${end_date} 23:59:59`, user_type];
      } else {
        // Door Step Buyers or other types - just users table
        tableJoin = 'none';
        query = `
          SELECT 
            u.id,
            u.name,
            u.email,
            u.mob_num,
            '' as address,
            '' as place,
            u.created_at
          FROM users u
          WHERE u.created_at BETWEEN ? AND ? AND u.user_type = ?
          ORDER BY u.created_at DESC
        `;
        params = [`${start_date} 00:00:00`, `${end_date} 23:59:59`, user_type];
      }

      console.log('🔍 Query Details:');
      console.log('   Table Join:', tableJoin || 'None (users only)');
      console.log('   SQL Query:', query.replace(/\s+/g, ' ').trim());
      console.log('   Query Params:', params);
      console.log('   Date Range in Query:', `${params[0]} to ${params[1]}`);
      
      const queryStartTime = Date.now();
      console.log('⏱️  Executing database query...');
      
      db.query(query, params, async (err, results) => {
        const queryDuration = Date.now() - queryStartTime;
        
        if (err) {
          console.error('═══════════════════════════════════════════════════════════');
          console.error('❌ signUpReport DATABASE ERROR');
          console.error('═══════════════════════════════════════════════════════════');
          console.error('   Error code:', err.code);
          console.error('   Error number:', err.errno);
          console.error('   Error message:', err.message);
          console.error('   SQL State:', err.sqlState);
          console.error('   Query Duration:', queryDuration, 'ms');
          console.error('   Failed Query:', query.replace(/\s+/g, ' ').trim());
          console.error('   Failed Params:', params);
          return res.json({
            status: 'error',
            msg: 'Error fetching report data',
            data: []
          });
        }
        
        console.log('═══════════════════════════════════════════════════════════');
        console.log('✅ signUpReport SUCCESS');
        console.log('═══════════════════════════════════════════════════════════');
        console.log(`   Total Records Found: ${results.length}`);
        console.log(`   Query Duration: ${queryDuration}ms`);
        console.log(`   User Type: ${user_type} (${userTypeName})`);
        console.log(`   Date Range: ${start_date} to ${end_date}`);
        
        if (results.length > 0) {
          console.log('📋 Sample Records (first 3):');
          results.slice(0, 3).forEach((record, index) => {
            console.log(`   Record ${index + 1}:`, {
              id: record.id,
              name: record.name || 'N/A',
              email: record.email || 'N/A',
              mobile: record.mob_num || 'N/A',
              address: record.address || 'N/A',
              place: record.place || 'N/A',
              created_at: record.created_at || 'N/A'
            });
          });
          
          // Summary statistics
          const withAddress = results.filter(r => r.address && r.address.trim() !== '').length;
          const withPlace = results.filter(r => r.place && r.place.trim() !== '').length;
          console.log('📊 Data Quality:');
          console.log(`   Records with address: ${withAddress}/${results.length} (${Math.round(withAddress/results.length*100)}%)`);
          console.log(`   Records with place: ${withPlace}/${results.length} (${Math.round(withPlace/results.length*100)}%)`);
        } else {
          console.log('⚠️  No records found for the specified criteria');
        }
        
        console.log('═══════════════════════════════════════════════════════════');
        
        const response = {
          status: 'success',
          msg: 'Report data retrieved',
          data: results
        };
        
        // Cache report data for 10 minutes (only if params provided)
        if (start_date && end_date && user_type) {
          try {
            const cacheKey = RedisCache.adminKey('signUpReport', null, { start_date, end_date, user_type });
            await RedisCache.set(cacheKey, response, '30days');
            console.log('💾 Sign up report cached');
          } catch (err) {
            console.error('Redis cache set error:', err);
          }
        }
        
        res.json(response);
      });
    } catch (error) {
      console.error('═══════════════════════════════════════════════════════════');
      console.error('❌ signUpReport EXCEPTION');
      console.error('═══════════════════════════════════════════════════════════');
      console.error('   Error:', error.message);
      console.error('   Error stack:', error.stack);
      res.status(500).json({
        status: 'error',
        msg: 'Error generating report',
        data: []
      });
    }
  }

  // Notifications
  static async custNotification(req, res) {
    try {
      console.log('🟢 AdminPanelController.custNotification called');
      console.log('   Fetching customers with FCM tokens');
      
      // Check Redis cache first
      const cacheKey = RedisCache.adminKey('custNotification');
      try {
        const cached = await RedisCache.get(cacheKey);
        if (cached) {
          console.log('⚡ Customer notification cache hit');
          return res.json(cached);
        }
      } catch (err) {
        console.error('Redis get error:', err);
      }
      
      // Use User model to get customers with FCM tokens
      const results = await User.findWithFcmTokenByUserType('C');
      console.log(`✅ custNotification: Found ${results.length} customers with FCM tokens`);
      if (results.length > 0) {
        console.log('   Sample customer:', {
          id: results[0].id,
          name: results[0].name
        });
      }
      
      const response = {
        status: 'success',
        msg: 'Customers retrieved',
        data: results
      };
      
      // Cache customer notification list for 5 minutes
      try {
        await RedisCache.set(cacheKey, response, '30days');
        console.log('💾 Customer notification list cached');
      } catch (err) {
        console.error('Redis cache set error:', err);
      }
      
      res.json(response);
    } catch (error) {
      console.error('❌ custNotification error:', error);
      console.error('   Error stack:', error.stack);
      res.status(500).json({
        status: 'error',
        msg: 'Error fetching customers',
        data: []
      });
    }
  }

  static async vendorNotification(req, res) {
    try {
      console.log('🟢 AdminPanelController.vendorNotification called');
      console.log('   Fetching vendors with FCM tokens');
      
      // Check Redis cache first
      const cacheKey = RedisCache.adminKey('vendorNotification');
      try {
        const cached = await RedisCache.get(cacheKey);
        if (cached) {
          console.log('⚡ Vendor notification cache hit');
          return res.json(cached);
        }
      } catch (err) {
        console.error('Redis get error:', err);
      }
      
      // Use User model to get vendors with FCM tokens
      const results = await User.findWithFcmTokenByUserType('S');
      console.log(`✅ vendorNotification: Found ${results.length} vendors with FCM tokens`);
      if (results.length > 0) {
        console.log('   Sample vendor:', {
          id: results[0].id,
          name: results[0].name
        });
      }
      
      const response = {
        status: 'success',
        msg: 'Vendors retrieved',
        data: {
          shops: results,
          shops_count: results.length
        }
      };
      
      // Cache vendor notification list for 5 minutes
      try {
        await RedisCache.set(cacheKey, response, '30days');
        console.log('💾 Vendor notification list cached');
      } catch (err) {
        console.error('Redis cache set error:', err);
      }
      
      res.json(response);
    } catch (error) {
      console.error('❌ vendorNotification error:', error);
      console.error('   Error stack:', error.stack);
      res.status(500).json({
        status: 'error',
        msg: 'Error fetching vendors',
        data: { shops: [], shops_count: 0 }
      });
    }
  }

  static async sendCustNotification(req, res) {
    try {
      const { cust_ids, message, title } = req.body;
      console.log('🟢 AdminPanelController.sendCustNotification called');
      console.log('   Request data:', {
        cust_ids: cust_ids || 'none',
        hasMessage: !!message,
        hasTitle: !!title
      });
      
      if (!cust_ids || !message || !title) {
        console.error('❌ sendCustNotification: Missing required fields');
        return res.json({
          status: 'error',
          msg: 'Customer IDs, message, and title are required',
          data: null
        });
      }
      
      // TODO: Implement actual notification sending logic
      // This would involve:
      // 1. Fetching FCM tokens for the cust_ids
      // 2. Sending notifications via Firebase
      // 3. Saving notification records to database
      
      // Invalidate customer notification cache after sending
      try {
        await RedisCache.delete(RedisCache.adminKey('custNotification'));
        console.log('🗑️  Invalidated customer notification cache after send');
      } catch (err) {
        console.error('Redis cache invalidation error:', err);
      }
      
      console.log('✅ sendCustNotification: Notification sent successfully');
      res.json({
        status: 'success',
        msg: 'Notification sent successfully',
        data: null
      });
    } catch (error) {
      console.error('❌ sendCustNotification error:', error);
      console.error('   Error stack:', error.stack);
      res.json({
        status: 'error',
        msg: 'Error sending notification',
        data: null
      });
    }
  }

  static async sendVendorNotification(req, res) {
    try {
      const { vendor_ids, message, title, criteria } = req.body;
      console.log('🟢 AdminPanelController.sendVendorNotification called');
      console.log('   Request data:', {
        vendor_ids: vendor_ids ? (Array.isArray(vendor_ids) ? vendor_ids.length : 1) : 0,
        hasMessage: !!message,
        hasTitle: !!title,
        criteria: criteria || 'none'
      });
      
      if (!vendor_ids || !message || !title) {
        console.error('❌ sendVendorNotification: Missing required fields');
        return res.json({
          status: 'error',
          msg: 'Vendor IDs, message, and title are required',
          data: null
        });
      }
      
      // TODO: Implement actual notification sending logic
      // This would involve:
      // 1. Fetching FCM tokens for the vendor_ids
      // 2. Sending notifications via Firebase
      // 3. Saving notification records to database
      
      // Invalidate vendor notification cache after sending
      try {
        await RedisCache.delete(RedisCache.adminKey('vendorNotification'));
        console.log('🗑️  Invalidated vendor notification cache after send');
      } catch (err) {
        console.error('Redis cache invalidation error:', err);
      }
      
      console.log('✅ sendVendorNotification: Notification sent successfully');
      res.json({
        status: 'success',
        msg: 'Notification sent successfully',
        data: null
      });
    } catch (error) {
      console.error('❌ sendVendorNotification error:', error);
      console.error('   Error stack:', error.stack);
      res.json({
        status: 'error',
        msg: 'Error sending notification',
        data: null
      });
    }
  }

  // Manage users (create/update)
  static async manageUsers(req, res) {
    try {
      const dbPromise = db.promise();
      const { user_id, names, email, password, phone } = req.body;
      const id = req.params.id || user_id; // Support both URL param and body param
console.log('hj');
      if (req.method === 'POST') {
        if (id) {
          // Update existing user
          const [userAdmins] = await dbPromise.query('SELECT * FROM user_admins WHERE id = ?', [id]);
          if (userAdmins.length === 0) {
            return res.json({
              status: 'error',
              msg: 'User not found',
              data: null
            });
          }

          const userAdmin = userAdmins[0];
          await dbPromise.query('UPDATE users SET name = ? WHERE id = ?', [names, userAdmin.user_id]);
          await dbPromise.query(
            'UPDATE user_admins SET name = ?, phone = ? WHERE id = ?',
            [names, phone || null, id]
          );

          // Invalidate related caches
          try {
            await RedisCache.invalidateTableCache('user_admins');
            await RedisCache.invalidateTableCache('users');
            await RedisCache.delete(RedisCache.adminKey('user', id));
            console.log('🗑️  Invalidated user caches after update');
          } catch (err) {
            console.error('Redis cache invalidation error:', err);
          }

          return res.json({
            status: 'success',
            msg: 'User updated successfully',
            data: null
          });
        } else {
          // Create new user
          if (!email || !password) {
            return res.json({
              status: 'error',
              msg: 'Email and password are required',
              data: null
            });
          }

          // Check if email exists
          const [existingUsers] = await dbPromise.query('SELECT id FROM users WHERE email = ?', [email]);
          if (existingUsers.length > 0) {
            return res.json({
              status: 'error',
              msg: 'Email already exists',
              data: null
            });
          }

          const bcrypt = require('bcryptjs');
          const hashedPassword = await bcrypt.hash(password, 10);

          // Create user
          const [userResult] = await dbPromise.query(
            'INSERT INTO users (name, email, password, user_type) VALUES (?, ?, ?, ?)',
            [names, email, hashedPassword, 'U']
          );

          // Create user_admin
          await dbPromise.query(
            'INSERT INTO user_admins (user_id, email, name, phone) VALUES (?, ?, ?, ?)',
            [userResult.insertId, email, names, phone || null]
          );

          // Invalidate related caches
          try {
            await RedisCache.invalidateTableCache('user_admins');
            await RedisCache.invalidateTableCache('users');
            console.log('🗑️  Invalidated user caches after create');
          } catch (err) {
            console.error('Redis cache invalidation error:', err);
          }

          return res.json({
            status: 'success',
            msg: 'User created successfully',
            data: null
          });
        }
      } else {
        // GET request - return user data if id provided
        if (req.params.id) {
          return AdminPanelController.getUserById(req, res);
        }
        return res.json({
          status: 'success',
          msg: 'User management page',
          data: { pagename: 'Users', user: null }
        });
      }
    } catch (error) {
      console.error('Manage users error:', error);
      res.status(500).json({
        status: 'error',
        msg: 'Error managing user',
        data: null
      });
    }
  }

  // Delete user
  static async deleteUser(req, res) {
    try {
      const { id } = req.params;
      const dbPromise = db.promise();

      const [userAdmins] = await dbPromise.query('SELECT * FROM user_admins WHERE id = ?', [id]);
      if (userAdmins.length === 0) {
        return res.json({
          status: 'error',
          msg: 'User not found',
          data: null
        });
      }

      const userAdmin = userAdmins[0];
      await dbPromise.query('DELETE FROM users WHERE id = ?', [userAdmin.user_id]);
      await dbPromise.query('DELETE FROM user_admins WHERE id = ?', [id]);

      // Invalidate related caches
      try {
        await RedisCache.invalidateTableCache('user_admins');
        await RedisCache.invalidateTableCache('users');
        await RedisCache.delete(RedisCache.adminKey('user', id));
        console.log('🗑️  Invalidated user caches after delete');
      } catch (err) {
        console.error('Redis cache invalidation error:', err);
      }

      return res.json({
        status: 'success',
        msg: 'User deleted successfully',
        data: null
      });
    } catch (error) {
      console.error('Delete user error:', error);
      res.status(500).json({
        status: 'error',
        msg: 'Error deleting user',
        data: null
      });
    }
  }

  // User password reset
  static async userPasswordReset(req, res) {
    try {
      const { id } = req.params;
      const { new_pass } = req.body;

      if (req.method === 'POST') {
        if (!new_pass) {
          return res.json({
            status: 'error',
            msg: 'New password is required',
            data: null
          });
        }

        const dbPromise = db.promise();
        // id can be either user_id (from users table) or user_admin id
        // Check if it's a user_id first
        const [users] = await dbPromise.query('SELECT id FROM users WHERE id = ?', [id]);
        let userId = id;
        
        if (users.length === 0) {
          // If not found in users, check if it's a user_admin id
          const [userAdmins] = await dbPromise.query('SELECT user_id FROM user_admins WHERE id = ?', [id]);
          if (userAdmins.length === 0) {
            return res.json({
              status: 'error',
              msg: 'User not found',
              data: null
            });
          }
          userId = userAdmins[0].user_id;
        }

        const bcrypt = require('bcryptjs');
        const hashedPassword = await bcrypt.hash(new_pass, 10);
        await dbPromise.query('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, userId]);

        // Invalidate user cache after password change
        try {
          await RedisCache.delete(RedisCache.adminKey('user', userId));
          await RedisCache.delete(RedisCache.adminKey('user', id));
          console.log('🗑️  Invalidated user cache after password reset');
        } catch (err) {
          console.error('Redis cache invalidation error:', err);
        }

        return res.json({
          status: 'success',
          msg: 'Password reset successfully',
          data: null
        });
      } else {
        // GET request - return form HTML or JSON
        return res.json({
          status: 'success',
          msg: 'Password reset form',
          data: { user_id: id }
        });
      }
    } catch (error) {
      console.error('Password reset error:', error);
      res.status(500).json({
        status: 'error',
        msg: 'Error resetting password',
        data: null
      });
    }
  }

  // Set permission page
  static async setPermission(req, res) {
    console.log('🟢 AdminController::setPermission called', {
      id: req.params.id,
      query: req.query,
      url: req.url
    });
    
    try {
      const { id } = req.params;
      
      // Check Redis cache first
      const cacheKey = RedisCache.adminKey('set_permission', id || 'all');
      try {
        const cached = await RedisCache.get(cacheKey);
        if (cached) {
          console.log('⚡ Set permission cache hit:', cacheKey);
          return res.json(cached);
        }
      } catch (err) {
        console.error('Redis get error:', err);
      }
      
      // Use DynamoDB models instead of SQL queries
      const UserAdmin = require('../models/UserAdmin');
      const PerPage = require('../models/PerPage');

      let userData = null;
      if (id) {
        console.log('🔵 Fetching user data for ID:', id);
        try {
          userData = await UserAdmin.findById(id);
          console.log('🔵 User data found:', userData ? 'Yes' : 'No', userData);
        } catch (err) {
          console.error('❌ Error fetching user data:', err.message);
          throw err;
        }
      }

      console.log('🔵 Fetching permissions...');
      let permissions = [];
      try {
        permissions = await PerPage.getAll();
        console.log('✅ Permissions fetched:', permissions.length, 'items');
        if (permissions.length > 0) {
          console.log('🔵 Sample permissions:', permissions.slice(0, 3));
        } else {
          console.warn('⚠️ No permissions found in database');
        }
      } catch (err) {
        console.error('❌ Error fetching permissions:', err.message);
        console.error('❌ Error stack:', err.stack);
        throw err;
      }

      console.log('🔵 Fetching all users...');
      let allUsers = [];
      try {
        allUsers = await UserAdmin.getAll();
        console.log('✅ Users fetched:', allUsers.length, 'items');
        if (allUsers.length > 0) {
          console.log('🔵 Sample users:', allUsers.slice(0, 3));
        } else {
          console.warn('⚠️ No users found in user_admins table');
        }
      } catch (err) {
        console.error('❌ Error fetching users:', err.message);
        console.error('❌ Error stack:', err.stack);
        throw err;
      }

      const response = {
        status: 'success',
        msg: 'Permission page',
        data: {
          pagename: 'Users Permission',
          user_data: userData,
          permission: permissions,
          user_id: id || '',
          users: allUsers
        }
      };

      console.log('✅ setPermission: Successfully returning data', {
        hasUserData: !!userData,
        permissionsCount: permissions.length,
        usersCount: allUsers.length
      });

      // Cache permission page data for 15 minutes
      try {
        await RedisCache.set(cacheKey, response, '30days');
        console.log('💾 Permission page data cached:', cacheKey);
      } catch (err) {
        console.error('Redis cache set error:', err);
      }

      return res.json(response);
    } catch (error) {
      console.error('❌ Set permission error:', error);
      console.error('❌ Error message:', error.message);
      console.error('❌ Error stack:', error.stack);
      res.status(500).json({
        status: 'error',
        msg: 'Error loading permission page: ' + error.message,
        data: null
      });
    }
  }

  // Store user permission
  static async storeUserPermission(req, res) {
    try {
      const { user_id } = req.body;
      if (!user_id) {
        return res.json({
          status: 'error',
          msg: 'User ID is required',
          data: null
        });
      }

      const permissions = [];
      for (const key in req.body) {
        if (key.startsWith('permission-')) {
          permissions.push(req.body[key]);
        }
      }

      const permissionString = permissions.join(',');
      
      // Use UserAdmin model to update permissions
      const UserAdmin = require('../models/UserAdmin');
      await UserAdmin.update(user_id, { page_permission: permissionString });

      // Invalidate related caches
      try {
        await RedisCache.invalidateTableCache('user_admins');
        await RedisCache.delete(RedisCache.adminKey('set_permission', user_id));
        await RedisCache.delete(RedisCache.adminKey('set_permission', 'all'));
        await RedisCache.delete(RedisCache.adminKey('user', user_id));
        console.log('🗑️  Invalidated permission caches after update');
      } catch (err) {
        console.error('Redis cache invalidation error:', err);
      }

      return res.json({
        status: 'success',
        msg: 'Permissions set successfully',
        data: null
      });
    } catch (error) {
      console.error('Store permission error:', error);
      res.status(500).json({
        status: 'error',
        msg: 'Error storing permissions',
        data: null
      });
    }
  }

  // Check distance
  static async checkDistance(req, res) {
    try {
      // Distance calculation logic would go here
      // This is typically used for calculating distance between two coordinates
      const { lat1, lon1, lat2, lon2 } = req.body;

      if (!lat1 || !lon1 || !lat2 || !lon2) {
        return res.json({
          status: 'error',
          msg: 'Coordinates are required',
          data: null
        });
      }

      // Haversine formula to calculate distance
      const R = 6371; // Radius of the Earth in km
      const dLat = (lat2 - lat1) * Math.PI / 180;
      const dLon = (lon2 - lon1) * Math.PI / 180;
      const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      const distance = R * c; // Distance in km

      return res.json({
        status: 'success',
        msg: 'Distance calculated',
        data: { distance: parseFloat(distance.toFixed(2)), unit: 'km' }
      });
    } catch (error) {
      console.error('Check distance error:', error);
      res.status(500).json({
        status: 'error',
        msg: 'Error calculating distance',
        data: null
      });
    }
  }
}

module.exports = AdminPanelController;

